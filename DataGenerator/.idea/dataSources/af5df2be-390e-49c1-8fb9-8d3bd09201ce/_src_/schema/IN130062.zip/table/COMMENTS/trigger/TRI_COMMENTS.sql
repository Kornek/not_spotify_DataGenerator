create trigger TRI_COMMENTS
	before insert
	on COMMENTS
	for each row
begin
    if :NEW.commentid is null then
      select commentid_seq.nextval into :NEW.commentid from dual;
    end if;
  end;