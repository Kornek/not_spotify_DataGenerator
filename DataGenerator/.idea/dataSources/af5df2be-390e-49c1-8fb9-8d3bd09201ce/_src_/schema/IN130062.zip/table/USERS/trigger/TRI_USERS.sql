create trigger TRI_USERS
	before insert
	on USERS
	for each row
begin
    if :NEW.userid is null then
      select userid_seq.nextval into :NEW.userid from dual;
    end if;
  end;