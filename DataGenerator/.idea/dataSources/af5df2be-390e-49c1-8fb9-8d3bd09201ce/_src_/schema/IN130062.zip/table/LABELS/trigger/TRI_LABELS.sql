create trigger TRI_LABELS
	before insert
	on LABELS
	for each row
begin
    if :NEW.labelid is null then
      select labelid_seq.nextval into :NEW.labelid from dual;
    end if;
  end;