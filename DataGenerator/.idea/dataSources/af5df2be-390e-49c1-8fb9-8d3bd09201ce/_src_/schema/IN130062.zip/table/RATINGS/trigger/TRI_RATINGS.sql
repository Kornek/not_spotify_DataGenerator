create trigger TRI_RATINGS
	before insert
	on RATINGS
	for each row
begin
    if :NEW.ratingid is null then
      select ratingid_seq.nextval into :NEW.ratingid from dual;
    end if;
  end;