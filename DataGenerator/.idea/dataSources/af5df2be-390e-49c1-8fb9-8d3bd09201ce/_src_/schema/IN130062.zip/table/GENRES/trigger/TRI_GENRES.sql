create trigger TRI_GENRES
	before insert
	on GENRES
	for each row
begin
    if :NEW.genreid is null then
      select genreid_seq.nextval into :NEW.genreid from dual;
    end if;
  end;