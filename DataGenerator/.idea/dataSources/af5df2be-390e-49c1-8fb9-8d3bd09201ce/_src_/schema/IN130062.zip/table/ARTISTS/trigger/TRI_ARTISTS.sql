create trigger TRI_ARTISTS
	before insert
	on ARTISTS
	for each row
begin
    if :NEW.artistid is null then
      select artistid_seq.nextval into :NEW.artistid from dual;
    end if;
  end;