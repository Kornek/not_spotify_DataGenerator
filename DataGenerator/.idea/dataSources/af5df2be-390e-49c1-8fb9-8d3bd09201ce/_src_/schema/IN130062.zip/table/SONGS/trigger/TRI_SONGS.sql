create trigger TRI_SONGS
	before insert
	on SONGS
	for each row
begin
    if :NEW.songid is null then
      select songid_seq.nextval into :NEW.songid from dual;
    end if;
  end;