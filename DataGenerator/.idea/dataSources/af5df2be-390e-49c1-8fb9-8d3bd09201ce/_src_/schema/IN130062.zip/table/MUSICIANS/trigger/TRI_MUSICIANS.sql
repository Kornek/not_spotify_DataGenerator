create trigger TRI_MUSICIANS
	before insert
	on MUSICIANS
	for each row
begin
    if :NEW.musicianid is null then
      select musicianid_seq.nextval into :NEW.musicianid from dual;
    end if;
  end;