create trigger K_TRIGGER
	before insert
	on KUNDEN
	for each row
DECLARE
  BEGIN
    :new.KNr := KNr_seq.Nextval;
  END;