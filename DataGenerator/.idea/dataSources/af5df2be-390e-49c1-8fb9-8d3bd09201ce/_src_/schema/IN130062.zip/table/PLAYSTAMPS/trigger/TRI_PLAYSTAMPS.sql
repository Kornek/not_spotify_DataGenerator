create trigger TRI_PLAYSTAMPS
	before insert
	on PLAYSTAMPS
	for each row
begin
    if :NEW.playstampid is null then
      select playstampid_seq.nextval into :NEW.playstampid from dual;
    end if;
  end;