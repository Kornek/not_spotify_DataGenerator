create trigger TRI_PLAYLISTS
	before insert
	on PLAYLISTS
	for each row
begin
    if :NEW.playlistid is null then
      select playlistid_seq.nextval into :NEW.playlistid from dual;
    end if;
  end;