create trigger TRI_ALBUMS
	before insert
	on ALBUMS
	for each row
begin
    if :NEW.albumid is null then
      select albumid_seq.nextval into :NEW.albumid from dual;
    end if;
  end;