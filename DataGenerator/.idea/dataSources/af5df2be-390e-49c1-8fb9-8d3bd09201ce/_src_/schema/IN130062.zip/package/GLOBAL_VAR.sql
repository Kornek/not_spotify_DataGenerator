create PACKAGE global_var IS
  v_emp_id EMPLOYEES.EMPLOYEEID%TYPE;
END;
accept x number prompt 'Please enter something: '
SET SERVEROUTPUT ON
DECLARE 
v_emp_totalsalary HR.EMPLOYEES.SALARY%TYPE;
v_emp_salary HR.EMPLOYEES.SALARY%TYPE;
v_emp_commission HR.EMPLOYEES.commission_pct%TYPE;
BEGIN
  SELECT EMPLOYEE_ID, salary, nvl(commission_pct, 0), nvl(SALARY+SALARY*COMMISSION_PCT,0)
  INTO v_emp_id, v_emp_salary, v_emp_commission, v_emp_totalsalary
  FROM hr.employees 
  WHERE EMPLOYEE_ID = 145;
  DBMS_OUTPUT.PUT_LINE('ID: ' || v_emp_id );
  DBMS_OUTPUT.PUT_LINE('Gehalt: ' || v_emp_salary ||' Provision: ' ||v_emp_commission || ' Gesamtgehalt'||v_emp_totalsalary);
END;