create view V_EVALUATION_DATA as
select V_EVALUATEES."Evaluatee ID" as "Evaluatee ID",
    V_EVALUATEES."Evaluatee First Name" as "Evaluatee First Name",
    V_EVALUATEES."Evaluatee Last Name" as "Evaluatee Last Name",
    EVALUATIONS.EVAL_ID as "Evaluation ID",
    EVALUATIONS.EVALSEMESTER as "Semester",
    EVALUATIONS.EVALYEAR as "Year",
    V_EVALUATORS."Evaluator First Name" as "Evaluator First Name",
    V_EVALUATORS."Evaluator ID" as "Evaluator ID",
    V_EVALUATORS."Evaluator Last Name" as "Evaluator Last Name",
    EVAL_ITEM_SCORES.EVAL_ITEM_ID as EVAL_ITEM_ID,
    EVAL_ITEM_SCORES.SCORE as SCORE 
 from EVAL_ITEM_SCORES EVAL_ITEM_SCORES,
    EVALUATIONS EVALUATIONS,
    V_EVALUATORS V_EVALUATORS,
    V_EVALUATEES V_EVALUATEES 
 where V_EVALUATEES.EVAL_ID=EVALUATIONS.EVAL_ID
    and V_EVALUATORS.EVAL_ID=EVALUATIONS.EVAL_ID
    and EVAL_ITEM_SCORES.EVAL_ID=EVALUATIONS.EVAL_ID

