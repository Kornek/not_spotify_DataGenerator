create FUNCTION authenticate(
 p_username IN VARCHAR2, --User_Name
 p_password IN VARCHAR2 -- Password
) RETURN BOOLEAN IS
   l_value NUMBER(1,0) := 0;
   l_returnvalue BOOLEAN;
 BEGIN
   BEGIN
     SELECT 1
       INTO l_value
       FROM users
      WHERE upper(users.username) = upper(p_username)
        AND upper(users.password) = upper(p_password);
   EXCEPTION
     WHEN no_data_found
          OR too_many_rows THEN
       l_value := 0;
     WHEN OTHERS THEN
       l_value := 0;
   END;
   l_returnvalue := l_value = 1;
   RETURN l_returnvalue;
 END;
