create trigger T_STDMAJOR_LOOKUP
	before insert or update
	on STDMAJOR_LOOKUP
	for each row
begin if inserting and :new."STDMAJOR_ID" is null then 
  for c1 in (select "STDMAJOR_LOOKUP_SEQ".nextval nv from dual) loop 
     :new."STDMAJOR_ID" := c1.nv;   end loop; end if; end;
