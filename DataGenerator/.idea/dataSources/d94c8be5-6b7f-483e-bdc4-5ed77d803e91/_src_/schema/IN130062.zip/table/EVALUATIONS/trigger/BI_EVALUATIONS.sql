create trigger BI_EVALUATIONS
	before insert
	on EVALUATIONS
	for each row
begin   
  if :NEW.EVAL_ID is null then 
    select EVAL_ID_SEQ.nextval into :NEW.EVAL_ID from dual; 
  end if; 
end; 
