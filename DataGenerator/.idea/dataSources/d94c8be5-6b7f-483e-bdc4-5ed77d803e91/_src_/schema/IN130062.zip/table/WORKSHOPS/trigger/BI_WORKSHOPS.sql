create trigger BI_WORKSHOPS
	before insert
	on WORKSHOPS
	for each row
begin   
  if :NEW.WKSHP_ID is null then 
    select WKSHP_ID_SEQ.nextval into :NEW.WKSHP_ID from dual; 
  end if; 
end; 
