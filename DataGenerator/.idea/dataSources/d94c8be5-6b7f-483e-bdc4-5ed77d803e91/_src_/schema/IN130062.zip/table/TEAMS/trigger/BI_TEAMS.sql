create trigger BI_TEAMS
	before insert
	on TEAMS
	for each row
begin   
  if :NEW.TEAMID is null then 
    select TEAMID_SEQ.nextval into :NEW.TEAMID from dual; 
  end if; 
end; 
