create trigger BI_EVAL_ITEMS
	before insert
	on EVAL_ITEMS
	for each row
begin   
  if :NEW.EVAL_ITEM_ID is null then 
    select EVAL_ITEM_ID_SEQ.nextval into :NEW.EVAL_ITEM_ID from dual; 
  end if; 
end; 
