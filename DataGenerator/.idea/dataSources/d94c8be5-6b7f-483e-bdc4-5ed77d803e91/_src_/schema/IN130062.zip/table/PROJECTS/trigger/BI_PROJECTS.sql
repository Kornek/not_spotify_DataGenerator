create trigger BI_PROJECTS
	before insert
	on PROJECTS
	for each row
begin   
  if :NEW.PROJECTID is null then 
    select PROJECTID_SEQ.nextval into :NEW.PROJECTID from dual; 
  end if; 
end; 
