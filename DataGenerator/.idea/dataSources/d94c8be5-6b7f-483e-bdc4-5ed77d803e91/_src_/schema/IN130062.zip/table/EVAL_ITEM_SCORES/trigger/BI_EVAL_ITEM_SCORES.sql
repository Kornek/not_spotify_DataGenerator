create trigger BI_EVAL_ITEM_SCORES
	before insert
	on EVAL_ITEM_SCORES
	for each row
begin   
  if :NEW.EVAL_SCORE_ID is null then 
    select EVAL_SCORE_ID_SEQ.nextval into :NEW.EVAL_SCORE_ID from dual; 
  end if; 
end; 
