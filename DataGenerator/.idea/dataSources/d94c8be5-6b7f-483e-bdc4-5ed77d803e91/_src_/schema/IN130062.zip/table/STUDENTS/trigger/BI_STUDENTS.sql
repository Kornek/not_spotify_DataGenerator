create trigger BI_STUDENTS
	before insert
	on STUDENTS
	for each row
begin   
  if :NEW.STDID is null then 
    select STDID_SEQ.nextval into :NEW.STDID from dual; 
  end if; 
end; 
