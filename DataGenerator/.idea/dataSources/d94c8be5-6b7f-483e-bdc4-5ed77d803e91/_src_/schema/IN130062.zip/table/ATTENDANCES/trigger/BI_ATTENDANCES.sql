create trigger BI_ATTENDANCES
	before insert
	on ATTENDANCES
	for each row
begin   
  if :NEW.ATTND_ID is null then 
    select ATTND_ID_SEQ.nextval into :NEW.ATTND_ID from dual; 
  end if; 
end; 
